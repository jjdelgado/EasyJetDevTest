namespace Interview
{
    public class Tests
    {

    }
}